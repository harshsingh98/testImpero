package com.example.exampleimpero.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exampleimpero.R;
import com.example.exampleimpero.databinding.ItemLayoutCategoryBinding;
import com.example.exampleimpero.databinding.ItemLayoutStripsRowBinding;
import com.example.exampleimpero.model.category.CategoryDetails;
import com.example.exampleimpero.model.category.SubCategory;
import com.example.exampleimpero.model.colorStrip.ColorPatch;

import java.util.List;

public class ColorPatchAdapter extends RecyclerView.Adapter<ColorPatchAdapter.MyViewHolder> {

    private Context context;
    private List<ColorPatch> listOfPatches;
    private OnItemClickListener onItemClickListener;

    public ColorPatchAdapter(Context context, List<ColorPatch> listOfPatches) {
        this.context = context;
        this.listOfPatches = listOfPatches;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(ItemLayoutStripsRowBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(ColorPatchAdapter.MyViewHolder holder, int position) {

        ColorPatch colorPatch = listOfPatches.get(position);

        holder.itemLayoutStripsRowBinding.mtxtPatchValue.setText(colorPatch.getValue());
        holder.itemLayoutStripsRowBinding.mcrdColorPatch.setCardBackgroundColor(colorPatch.getColorStateList());

        holder.itemLayoutStripsRowBinding.mcrdColorPatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              onItemClickListener.onClick(holder.itemLayoutStripsRowBinding.mtxtPatchValue.getText().toString(),
                      holder.itemLayoutStripsRowBinding.mcrdColorPatch.getCardBackgroundColor());
            }
        });
    }

    @Override
    public int getItemCount() {
        return listOfPatches.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ItemLayoutStripsRowBinding itemLayoutStripsRowBinding;

        public MyViewHolder(ItemLayoutStripsRowBinding itemView) {
            super(itemView.getRoot());

            this.itemLayoutStripsRowBinding = itemView;
        }
    }

    public interface OnItemClickListener {
        void onClick(String value, ColorStateList colorValue);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }
}

