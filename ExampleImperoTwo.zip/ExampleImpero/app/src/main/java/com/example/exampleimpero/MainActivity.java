package com.example.exampleimpero;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Toast;

import com.example.exampleimpero.adapter.CategoryAdapter;
import com.example.exampleimpero.adapter.ProductsAdapter;
import com.example.exampleimpero.adapter.SubCategoryAdapter;
import com.example.exampleimpero.api.ApiClient;
import com.example.exampleimpero.api.ApiEndpoints;
import com.example.exampleimpero.databinding.ActivityMainBinding;
import com.example.exampleimpero.model.category.CategoryDetails;
import com.example.exampleimpero.model.category.CategoryMain;
import com.example.exampleimpero.model.category.CategoryResult;
import com.example.exampleimpero.model.category.ProductDetails;
import com.example.exampleimpero.model.category.SubCategory;
import com.example.exampleimpero.model.product.ProductResult;
import com.example.exampleimpero.model.product.ProductsMain;
import com.example.exampleimpero.views.ThirdTaskActivity;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding activityMainBinding;

    private ApiEndpoints apiEndpoints;              //interface of endpoints

    //adapter
    private CategoryAdapter categoryAdapter;        //adapter for category List
    private SubCategoryAdapter subCategoryAdapter;  //adapter for sub-category List
    private ProductsAdapter productsAdapter;        //adapter for products list during pagination

    //lists
    private List<CategoryDetails> listOfCategory = new ArrayList<>();    // list of categories
    private List<SubCategory> listOfSubCategories = new ArrayList<>();   // list of sub-categories
    private List<ProductResult> listOfProducts = new ArrayList<>();     // list of products

    //variables for pagination
    private int pageIndex = 1;
    private int categoryID = 0;
    private int subCategoryId = 0;
    private boolean isLoading = false, isLastPage = false;
    private int itemSize = 0;
    //static int currentPage = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = activityMainBinding.getRoot();
        setContentView(view);

        init();
    }

    private void init() {
        getSupportActionBar().hide();

        pageIndex = 1;
        isLastPage = false;

        activityMainBinding.topNavBar.acivFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navToThirdTask();
            }
        });

        activityMainBinding.topNavBar.acivSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Search clicked", Toast.LENGTH_SHORT).show();
            }
        });

        apiEndpoints = ApiClient.getClient().create(ApiEndpoints.class);

        //for fetching categories
        callCategoriesApi();

        activityMainBinding.rcycListOfSubProducts.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                Log.i("Check", "onScrollChanged:Came " );
                View view = (View) activityMainBinding.scrollView.getChildAt(activityMainBinding.scrollView.getChildCount() - 1);

                int diff = (view.getBottom() - (activityMainBinding.scrollView.getHeight() + activityMainBinding.scrollView.getScrollY()));

                if (diff == 0){
                    Log.i("Check", "onScrollChanged:InDiff " + isLoading + "," + isLastPage);
                    if (isLoading && !isLastPage){
                        Log.i("Check", "onScrollChanged:InIsLoading " + isLoading + "," + isLastPage);
                        isLastPage = false;
                        pageIndex = pageIndex + 1;
                        callSubCategories(categoryID);
                    }
                }
            }
        });
    }

    private void callCategoriesApi() {
        activityMainBinding.progressBar.setVisibility(View.VISIBLE);

        Call<CategoryMain> catMain = apiEndpoints.getCategory(0,
                "Google",
                "Android SDK built for x86",
                "",
                pageIndex);

        catMain.enqueue(new Callback<CategoryMain>() {
            @Override
            public void onResponse(Call<CategoryMain> call, Response<CategoryMain> response) {
                activityMainBinding.progressBar.setVisibility(View.GONE);
                CategoryMain categoryMain = response.body();
                Integer statusCode = categoryMain.getStatus();
                String message = categoryMain.getMessage();

                if (statusCode == 200) {
                    isLoading = true;
                    itemSize = categoryMain.getResult().getCategory().size();
                    listOfCategory = categoryMain.getResult().getCategory();
                    if (pageIndex == 1){
                        listOfSubCategories.clear();
                    }
                    listOfCategory = categoryMain.getResult().getCategory();
                }

                fillCategories();

            }

            @Override
            public void onFailure(Call<CategoryMain> call, Throwable t) {
                activityMainBinding.progressBar.setVisibility(View.GONE);
                call.cancel();
            }
        });

    }

    //for inflating categories list
    private void fillCategories() {
        if (listOfCategory != null) {
            categoryAdapter = new CategoryAdapter(this, listOfCategory);
            activityMainBinding.rcycCategoryTitles.setLayoutManager(
                    new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            activityMainBinding.rcycCategoryTitles.setAdapter(categoryAdapter);

            categoryID = listOfCategory.get(0).getId();

            categoryAdapter.setOnItemClickListener(new CategoryAdapter.OnItemClickListener() {
                @Override
                public void onClick(List<SubCategory> subCategory, boolean showContent) {
                    if (!showContent) {
                        activityMainBinding.rcycListOfSubProducts.setVisibility(View.GONE);
                    } else {
                        activityMainBinding.rcycListOfSubProducts.setVisibility(View.VISIBLE);
                        //commented note mentioned as to not show products
                    /*listOfSubCategories = subCategory;
                    fillSubCategories();*/
                    }

                }

                @Override
                public void sendCategoryId(List<SubCategory> subCategory, int categoryId) {
                    Log.i("Check", "sendCategoryId: " + categoryId);
                    //categoryID = categoryId;
                    listOfSubCategories = subCategory;
                    fillSubCategories();
                }
            });
        }
    }

    //for sub categories fetching
    private void callSubCategories(int categoryId) {
        activityMainBinding.progressBar.setVisibility(View.VISIBLE);
        Call<CategoryMain> catMain = apiEndpoints.getSubCategory(categoryId,
                pageIndex);

        Log.i("CHeck", "callSubCategories: " + categoryId + "," + pageIndex);

        catMain.enqueue(new Callback<CategoryMain>() {
            @Override
            public void onResponse(Call<CategoryMain> call, Response<CategoryMain> response) {
                CategoryMain categoryMain = response.body();
                Integer statusCode = categoryMain.getStatus();
                String message = categoryMain.getMessage();
                Log.i("Check", "onResponseCheck: " + new Gson().toJson(response));
                if (statusCode == 200) {
                    activityMainBinding.progressBar.setVisibility(View.GONE);
                    isLoading = true;
                    itemSize = categoryMain.getResult().getCategory().size();
                    listOfCategory = categoryMain.getResult().getCategory();
                    if (pageIndex == 1){
                        listOfSubCategories.clear();
                    }
                    //listOfSubCategories = categoryMain.getResult().getCategory().get(0).getSubCategories();
                    for (int i = 0; i <= categoryMain.getResult().getCategory().size(); i++) {
                        for (int j = 0; j < categoryMain.getResult().getCategory().get(i).getSubCategories().size(); j++) {
                            SubCategory subCategory = new SubCategory();
                            subCategory.setId(categoryMain.getResult().getCategory().get(i).getSubCategories().get(j).getId());
                            subCategory.setName(categoryMain.getResult().getCategory().get(i).getSubCategories().get(j).getName());
                            subCategory.setProduct(categoryMain.getResult().getCategory().get(i).getSubCategories().get(j).getProduct());
                            listOfSubCategories.add(subCategory);
                        }
                    }
                    fillSubCategories();
                }

            }

            @Override
            public void onFailure(Call<CategoryMain> call, Throwable t) {
                call.cancel();
            }
        });
    }

    private void fillSubCategories() {
        if (listOfSubCategories != null) {
            subCategoryAdapter = new SubCategoryAdapter(this, listOfSubCategories);
            activityMainBinding.rcycListOfSubProducts.setLayoutManager(
                    new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
            activityMainBinding.rcycListOfSubProducts.setAdapter(subCategoryAdapter);
        }

    }

    private void callProductsApi() {

        Call<ProductsMain> productMain = apiEndpoints.getProductList(0,
                subCategoryId);

        productMain.enqueue(new Callback<ProductsMain>() {
            @Override
            public void onResponse(Call<ProductsMain> call, Response<ProductsMain> response) {
                ProductsMain productsMain = response.body();
                Integer statusCode = productsMain.getStatus();
                String message = productsMain.getMessage();

                if (statusCode == 200) {
                    listOfProducts = productsMain.getResult();
                }

                fillProducts();
            }

            @Override
            public void onFailure(Call<ProductsMain> call, Throwable t) {
                call.cancel();
            }
        });


    }

    private void fillProducts() {
        /*if (listOfProducts != null && listOfProducts.size() > 0){
            productsAdapter = new ProductsAdapter(this, listOfProducts);
            itemLayoutSubCategoryBinding.rcycListOfProducts.setLayoutManager(
                    new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            itemLayoutSubCategoryBinding.rcycListOfProducts.setAdapter(productsAdapter);
        }*/
    }

    private void navToThirdTask(){
        Intent iThirdTask = new Intent(this, ThirdTaskActivity.class);
        startActivity(iThirdTask);
    }
}