package com.example.exampleimpero.model.colorStrip;

import android.content.res.ColorStateList;

public class ColorPatch {
    private String value;
    private ColorStateList colorStateList;

    public ColorPatch(){}

    public ColorPatch(String value, ColorStateList colorStateList) {
        this.value = value;
        this.colorStateList = colorStateList;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public ColorStateList getColorStateList() {
        return colorStateList;
    }

    public void setColorStateList(ColorStateList colorStateList) {
        this.colorStateList = colorStateList;
    }
}
