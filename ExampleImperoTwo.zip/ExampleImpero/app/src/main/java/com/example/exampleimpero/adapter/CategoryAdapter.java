package com.example.exampleimpero.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exampleimpero.R;
import com.example.exampleimpero.databinding.ItemLayoutCategoryBinding;
import com.example.exampleimpero.model.category.CategoryDetails;
import com.example.exampleimpero.model.category.CategoryResult;
import com.example.exampleimpero.model.category.SubCategory;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {

    private Context context;
    private List<CategoryDetails> listOfCategory;
    private int lastSelectedPosition = 0;
    private OnItemClickListener onItemClickListener;

    public CategoryAdapter(Context context, List<CategoryDetails> listOfCategories) {
        this.context = context;
        this.listOfCategory = listOfCategories;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(ItemLayoutCategoryBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(CategoryAdapter.MyViewHolder holder, int position) {

        Typeface typefaceRegular = ResourcesCompat.getFont(context, R.font.open_sans);
        Typeface typefaceBold = ResourcesCompat.getFont(context, R.font.open_sans_bold);


        if (lastSelectedPosition == position) {
            holder.itemLayoutCategoryBinding.mtxtCategoryTitles.setTypeface(typefaceBold);
        } else {
            holder.itemLayoutCategoryBinding.mtxtCategoryTitles.setTypeface(typefaceRegular);
        }

        CategoryDetails categoryResult = listOfCategory.get(position);
        holder.itemLayoutCategoryBinding.mtxtCategoryTitles.setText(categoryResult.getName());

        onItemClickListener.sendCategoryId(categoryResult.getSubCategories(), categoryResult.getId());

        holder.itemLayoutCategoryBinding.linMainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lastSelectedPosition = position;
                notifyDataSetChanged();

                if (categoryResult.getSubCategories() != null &&
                        categoryResult.getSubCategories().size() > 0) {

                    if (categoryResult.getSubCategories().get(position).getProduct() != null
                            && categoryResult.getSubCategories().get(position).getProduct().size() > 0) {
                        onItemClickListener.onClick(categoryResult.getSubCategories(), true);
                    } else {
                        onItemClickListener.onClick(categoryResult.getSubCategories(), false);
                    }
                }
                else{
                    onItemClickListener.onClick(categoryResult.getSubCategories(), false);
                }


                //onItemClickListener.sendCategoryId(categoryResult.getSubCategories(), categoryResult.getId());       //as suggested in note not to show other subcategory products
            }
        });
    }

    @Override
    public int getItemCount() {
        return listOfCategory.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ItemLayoutCategoryBinding itemLayoutCategoryBinding;

        public MyViewHolder(ItemLayoutCategoryBinding itemView) {
            super(itemView.getRoot());

            this.itemLayoutCategoryBinding = itemView;
        }
    }

    public interface OnItemClickListener {
        void onClick(List<SubCategory> subCategory, boolean showContent);

        void sendCategoryId(List<SubCategory> subCategory, int categoryId);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }
}

