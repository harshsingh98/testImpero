package com.example.exampleimpero.model.category;

import com.example.exampleimpero.model.category.ProductDetails;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SubCategory {

    @SerializedName("Id")
    @Expose
    private Integer id;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Product")
    @Expose
    private List<ProductDetails> product = null;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ProductDetails> getProduct() {
        return product;
    }

    public void setProduct(List<ProductDetails> product) {
        this.product = product;
    }

}
