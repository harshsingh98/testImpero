package com.example.exampleimpero.model.category;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CategoryResult {

    @SerializedName("Category")
    @Expose
    private List<CategoryDetails> category = null;

    public List<CategoryDetails> getCategory() {
        return category;
    }

    public void setCategory(List<CategoryDetails> category) {
        this.category = category;
    }

}
