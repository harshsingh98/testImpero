package com.example.exampleimpero.model.category;

public class CategoryRequestModel {
    private int categoryId;
    private String deviceManufacturer;
    private String deviceModel;
    private String deviceToken;
    private int pageIndex;

    public CategoryRequestModel(int categoryId, String deviceManufacturer, String deviceModel, String deviceToken, int pageIndex) {
        this.categoryId = categoryId;
        this.deviceManufacturer = deviceManufacturer;
        this.deviceModel = deviceModel;
        this.deviceToken = deviceToken;
        this.pageIndex = pageIndex;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getDeviceManufacturer() {
        return deviceManufacturer;
    }

    public void setDeviceManufacturer(String deviceManufacturer) {
        this.deviceManufacturer = deviceManufacturer;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }
}
