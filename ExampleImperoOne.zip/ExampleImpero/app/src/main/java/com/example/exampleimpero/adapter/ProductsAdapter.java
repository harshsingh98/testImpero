package com.example.exampleimpero.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.exampleimpero.R;
import com.example.exampleimpero.databinding.ItemLayoutCategoryBinding;
import com.example.exampleimpero.databinding.ItemLayoutProductsListBinding;
import com.example.exampleimpero.model.category.ProductDetails;
import com.google.android.material.shape.CornerFamily;

import java.util.ArrayList;
import java.util.List;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.MyViewHolder> {

    private Context context;
    private List<ProductDetails> listOfProducts;
    private float radius;

    public ProductsAdapter(Context context, List<ProductDetails> listOfProducts) {
        this.context = context;
        this.listOfProducts = listOfProducts;
        radius = context.getResources().getDimension(R.dimen.dp8);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(ItemLayoutProductsListBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(ProductsAdapter.MyViewHolder holder, int position) {
        ProductDetails productDetails = listOfProducts.get(position);
        holder.itemLayoutProductsListBinding.mtxtThumbnailTags.setText(productDetails.getPriceCode());
        Glide.with(context)
                .load(productDetails.getImageName())
                .placeholder(R.drawable.palceholder_image)
                .into(holder.itemLayoutProductsListBinding.sivProductThumbnail);
        holder.itemLayoutProductsListBinding.sivProductThumbnail.setShapeAppearanceModel
                (holder.itemLayoutProductsListBinding.sivProductThumbnail.getShapeAppearanceModel()
                .toBuilder()
                .setAllCorners(CornerFamily.ROUNDED,radius)
                .build());
        holder.itemLayoutProductsListBinding.mtxtProductName.setText(productDetails.getName());
    }

    @Override
    public int getItemCount() {
        return listOfProducts.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ItemLayoutProductsListBinding itemLayoutProductsListBinding;

        public MyViewHolder(@NonNull ItemLayoutProductsListBinding itemView) {
            super(itemView.getRoot());

            this.itemLayoutProductsListBinding = itemView;
        }
    }
}
