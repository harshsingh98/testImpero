package com.example.exampleimpero.api;

import com.example.exampleimpero.model.category.CategoryMain;
import com.example.exampleimpero.model.category.CategoryRequestModel;
import com.example.exampleimpero.model.product.ProductsMain;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiEndpoints {
    /*@POST("/api/API/Product/DashBoard")
    Call<CategoryRequestModel> getCategory(@Body CategoryRequestModel categoryRequestModel);*/

    @FormUrlEncoded
    @POST("/api/API/Product/DashBoard")
    Call<CategoryMain> getCategory(@Field("categoryId") int categoryId,
                                   @Field("deviceManufacturer") String deviceManufacturer,
                                   @Field("deviceModel") String deviceModel,
                                   @Field("deviceToken") String deviceToken,
                                   @Field("pageIndex") int pageIndex);

    @FormUrlEncoded
    @POST("/api/users?")
    Call<CategoryMain> getSubCategory(@Field("categoryId") int categoryId,
                                              @Field("pageIndex") int pageIndex);

    @FormUrlEncoded
    @POST("/api/API/Product/ProductList")
    Call<ProductsMain> getProductList(@Field("pageIndex") int pageIndex,
                                      @Field("subCategoryId") int subCategoryId);
}
