package com.example.exampleimpero.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exampleimpero.databinding.ItemLayoutCategoryBinding;
import com.example.exampleimpero.databinding.ItemLayoutSubCategoryBinding;
import com.example.exampleimpero.model.category.ProductDetails;
import com.example.exampleimpero.model.category.SubCategory;
import com.example.exampleimpero.model.product.ProductsMain;

import java.util.ArrayList;
import java.util.List;

public class SubCategoryAdapter extends RecyclerView.Adapter<SubCategoryAdapter.MyViewHolder> {

    private Context context;
    private List<SubCategory> listOfSubCategory;
    private ProductsAdapter productsAdapter;
    private List<ProductDetails> listOfProducts = new ArrayList<>();

    public SubCategoryAdapter(Context context, List<SubCategory> listOfSubCategory) {
        this.context = context;
        this.listOfSubCategory = listOfSubCategory;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(ItemLayoutSubCategoryBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(SubCategoryAdapter.MyViewHolder holder, int position) {
        SubCategory subCategory = listOfSubCategory.get(position);

        holder.itemLayoutSubCategoryBinding.mtxtSubCategoryTitles.setText(subCategory.getName());

        listOfProducts = subCategory.getProduct();

        if (listOfProducts != null && listOfProducts.size() > 0){
            productsAdapter = new ProductsAdapter(context, listOfProducts);
            holder.itemLayoutSubCategoryBinding.rcycListOfProducts.setLayoutManager(
                    new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
            holder.itemLayoutSubCategoryBinding.rcycListOfProducts.setAdapter(productsAdapter);
        }

    }

    @Override
    public int getItemCount() {
        return listOfSubCategory.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ItemLayoutSubCategoryBinding itemLayoutSubCategoryBinding;

        public MyViewHolder(@NonNull ItemLayoutSubCategoryBinding itemView) {
            super(itemView.getRoot());
            this.itemLayoutSubCategoryBinding = itemView;
        }
    }
}
