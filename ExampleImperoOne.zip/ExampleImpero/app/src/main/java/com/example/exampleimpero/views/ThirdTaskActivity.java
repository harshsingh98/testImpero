package com.example.exampleimpero.views;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;

import com.example.exampleimpero.R;
import com.example.exampleimpero.adapter.ColorPatchAdapter;
import com.example.exampleimpero.databinding.ActivityMainBinding;
import com.example.exampleimpero.databinding.ActivityThirdTaskBinding;
import com.example.exampleimpero.model.colorStrip.ColorPatch;

import java.util.ArrayList;
import java.util.List;

public class ThirdTaskActivity extends AppCompatActivity {

    private ActivityThirdTaskBinding activityThirdTaskBinding;

    private String[] stripHardnessValues = {"0", "110", "250", "500", "1000"};
    private String[] stripTotalChlorineValues = {"0", "1", "3", "5", "10"};
    private String[] stripFreeChlorineValues = {"0", "1", "3", "5", "10"};
    private String[] stripPhValues = {"6.2", "6.8", "7.2", "7.8", "8.4"};
    private String[] stripAlkalinityValues = {"0", "40", "120", "180", "240"};
    private String[] stripCyanuricAcidValues = {"0", "50", "100", "150", "300"};

    private int[] stripHardnessColors = {getResources().getColor(R.color.colorOne),
            getResources().getColor(R.color.colorTwo),
            getResources().getColor(R.color.colorThree),
            getResources().getColor(R.color.colorFour),
            getResources().getColor(R.color.colorFive)};

    private int[] stripTotalChlorineColors = {getResources().getColor(R.color.colorOne),
            getResources().getColor(R.color.colorTwo),
            getResources().getColor(R.color.colorThree),
            getResources().getColor(R.color.colorFour),
            getResources().getColor(R.color.colorFive)};

    private int[] stripFreeChlorineColors = {getResources().getColor(R.color.colorOne),
            getResources().getColor(R.color.colorTwo),
            getResources().getColor(R.color.colorThree),
            getResources().getColor(R.color.colorFour),
            getResources().getColor(R.color.colorFive)};

    private int[] stripPhColors = {getResources().getColor(R.color.colorOne),
            getResources().getColor(R.color.colorTwo),
            getResources().getColor(R.color.colorThree),
            getResources().getColor(R.color.colorFour),
            getResources().getColor(R.color.colorFive)};

    private int[] stripAlkalinityColors = {getResources().getColor(R.color.colorOne),
            getResources().getColor(R.color.colorTwo),
            getResources().getColor(R.color.colorThree),
            getResources().getColor(R.color.colorFour),
            getResources().getColor(R.color.colorFive)};

    private int[] stripCyanuricAcidColors = {getResources().getColor(R.color.colorOne),
            getResources().getColor(R.color.colorTwo),
            getResources().getColor(R.color.colorThree),
            getResources().getColor(R.color.colorFour),
            getResources().getColor(R.color.colorFive)};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityThirdTaskBinding = ActivityThirdTaskBinding.inflate(getLayoutInflater());
        View view = activityThirdTaskBinding.getRoot();
        setContentView(view);

        init();
    }

    private void init(){
        fillHardness();
    }

    private void fillHardness(){
        ColorPatchAdapter colorPatchAdapter;
        List<ColorPatch> listOfColorPatches = new ArrayList<>();

        for (int i = 0; i <= stripHardnessValues.length; i++){
            ColorPatch colorPatch = new ColorPatch();
            colorPatch.setValue(stripHardnessValues[i]);
            colorPatch.setColorStateList(ColorStateList.valueOf(stripHardnessColors[i]));
            listOfColorPatches.add(colorPatch);
        }

        colorPatchAdapter = new ColorPatchAdapter(this, listOfColorPatches);
        activityThirdTaskBinding.rcycHardness.setLayoutManager(new GridLayoutManager(this, 5, RecyclerView.HORIZONTAL, false));

        colorPatchAdapter.setOnItemClickListener(new ColorPatchAdapter.OnItemClickListener() {
            @Override
            public void onClick(String value, ColorStateList colorValue) {
                activityThirdTaskBinding.tietHardness.setText(value);
                activityThirdTaskBinding.viewOne.setCardBackgroundColor(colorValue);
            }
        });
    }
}