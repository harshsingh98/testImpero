package com.example.exampleimpero.constants;

public class ApiConstants {
    public static final String BASE_URL = "http://esptiles.imperoserver.in";
}
